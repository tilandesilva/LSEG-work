#!/bin/bash
sudo yum -y update
mkdir /tmp/logs